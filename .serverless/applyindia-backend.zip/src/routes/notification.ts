import { Router } from "express";
import {
  addCompleteNotification,
  approveNotification,
  archiveNotification,
  editCompleteNotification,
  getHomePageNotifications,
  getNotificationById,
  getNotificationsByCategory,
  unarchiveNotification,
  viewNotifications,
} from "../services/notificationService";

const router = Router();

/******************************************************************************
 *                            PUBLIC ROUTES
 ******************************************************************************/

// Home page notifications
router.get("/home", async (_req, res) => {
  try {
    const grouped = await getHomePageNotifications();
    res.json({ success: true, data: grouped });
  } catch (err) {
    res.status(500).json({
      success: false,
      error: "Database error",
    });
  }
});

// Category + search + pagination
router.get("/category/:category", async (req, res) => {
  try {
    const { category } = req.params;
    const { searchValue, lastEvaluatedKey } = req.query;
    const limit = Number(req.query.limit) || 20;

    const result = await getNotificationsByCategory(
      category,
      limit,
      typeof lastEvaluatedKey === "string" ? lastEvaluatedKey : undefined,
      typeof searchValue === "string" ? searchValue : undefined
    );

    res.json({
      success: true,
      ...result,
    });
  } catch (err) {
    res.status(500).json({
      success: false,
      error: "Database error",
    });
  }
});

/******************************************************************************
 *                            ADMIN ROUTES
 *        (Protected by Cognito Authorizer at API Gateway)
 ******************************************************************************/

// Add notification
router.post("/add", async (req, res) => {
  try {
    const result = await addCompleteNotification(req.body);
    res.json({ success: true, data: result });
  } catch (error) {
    console.error("Error adding notification:", error);
    res.status(500).json({
      success: false,
      error: "Failed to add notification",
    });
  }
});

// View all notifications
router.get("/view", async (_req, res) => {
  try {
    const notifications = await viewNotifications();
    res.json({ success: true, notifications });
  } catch (err) {
    res.status(500).json({
      success: false,
      error: "Database error",
    });
  }
});

// Get notification by ID
router.get("/getById/:id", async (req, res) => {
  try {
    const notification = await getNotificationById(req.params.id);
    if (!notification) {
      return res.status(404).json({
        success: false,
        error: "Notification not found",
      });
    }
    res.json({ success: true, notification });
  } catch (err) {
    res.status(500).json({
      success: false,
      error: "Database error",
    });
  }
});

// Edit notification
router.put("/edit/:id", async (req, res) => {
  try {
    const notification = await editCompleteNotification(
      req.params.id,
      req.body
    );
    res.json({ success: true, notification });
  } catch (err) {
    res.status(500).json({
      success: false,
      error: "Database error",
    });
  }
});

// Approve notification
router.patch("/approve/:id", async (req, res) => {
  try {
    const notification = await approveNotification(
      req.params.id,
      "admin"
    );
    res.json({ success: true, notification });
  } catch (err) {
    res.status(500).json({
      success: false,
      error: "Database error",
    });
  }
});

// Archive notification
router.delete("/delete/:id", async (req, res) => {
  try {
    const notification = await archiveNotification(req.params.id);
    res.json({ success: true, notification });
  } catch (err) {
    res.status(500).json({
      success: false,
      error: "Database error",
    });
  }
});

// Unarchive notification
router.patch("/unarchive/:id", async (req, res) => {
  try {
    const notification = await unarchiveNotification(req.params.id);
    res.json({ success: true, notification });
  } catch (err) {
    res.status(500).json({
      success: false,
      error: "Failed to unarchive",
    });
  }
});

export default router;
